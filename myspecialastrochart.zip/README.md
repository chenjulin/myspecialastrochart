# 我的星盤網站 myspecialastrochart 🌟

這是一個使用 React + TypeScript 製作的個人星盤查詢網站。

## ✨ 使用方式

1. 安裝依賴套件：

```
npm install
```

2. 本地啟動網站：

```
npm start
```

3. 打包網站：

```
npm run build
```

## ☁️ 部署方式（使用 Vercel）

1. 把這個專案上傳到 GitHub
2. 到 https://vercel.com 登入並連接 GitHub
3. 點「New Project」，選擇這個 repo
4. 按「Deploy」就完成啦！

網站網址會是：https://myspecialastrochart.vercel.app

🎉
