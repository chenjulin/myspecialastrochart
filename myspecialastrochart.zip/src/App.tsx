import React from 'react';
import AstroChartForm from './AstroChartForm';

function App() {
  return (
    <div>
      <AstroChartForm />
    </div>
  );
}

export default App;
