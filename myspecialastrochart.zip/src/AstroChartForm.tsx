import React from "react";
import { useState } from "react";

interface BirthData {
  name: string;
  date: string;
  time: string;
  place: string;
}

const AstroChartForm: React.FC = () => {
  const [data, setData] = useState<BirthData>({
    name: "",
    date: "",
    time: "",
    place: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    console.log("提交的資料：", data);
    alert("星盤資料已送出（開發中）！");
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "600px", margin: "auto" }}>
      <h1 style={{ fontSize: "24px", textAlign: "center", marginBottom: "1rem" }}>個人星盤查詢</h1>
      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        <input name="name" placeholder="姓名" value={data.name} onChange={handleChange} />
        <input name="date" type="date" value={data.date} onChange={handleChange} />
        <input name="time" type="time" value={data.time} onChange={handleChange} />
        <input name="place" placeholder="出生地點（如：台北）" value={data.place} onChange={handleChange} />
        <button onClick={handleSubmit}>生成星盤</button>
      </div>
    </div>
  );
};

export default AstroChartForm;
